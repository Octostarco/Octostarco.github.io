# coredns

This folder contains the configuration files for `coredns`.