If you are a developer, most likely you'll want to have your `octostar-superset` codebase available for editing.

## PORTS EXPOSURE (from k8s to your host): You need `kubefwd` installed.

Inside the `octostar-superset` repository there's a helper script:
`k8sdev/forward.sh`.