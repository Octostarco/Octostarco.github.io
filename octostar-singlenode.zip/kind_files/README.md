# Kind

This folder contains the configuration files for the initialization of `kind` and `nvkind` clusters.