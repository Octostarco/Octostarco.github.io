# GPU capable machine

In case you have a machine that has a GPU attached to it, it is possible to use it.

We tested this setup on an Ubuntu 22.04 with Nvidia drivers 560. Versioning is important as it needs to be consistent across the stack. \
Our streamlit/ML Docker App image is based on this official image provided by NVIDIA: `nvidia/cuda:12.6.0-base-ubuntu22.04`

The host has to be provisioned with the necessary drivers:
 - `$ ubuntu-drivers install`
 - `$ nvidia-smi` (needs to return a similar output)

```
Thu Aug 29 14:59:58 2024
+-----------------------------------------------------------------------------------------+
| NVIDIA-SMI 560.35.03              Driver Version: 560.35.03      CUDA Version: 12.6     |
|-----------------------------------------+------------------------+----------------------+
| GPU  Name                 Persistence-M | Bus-Id          Disp.A | Volatile Uncorr. ECC |
| Fan  Temp   Perf          Pwr:Usage/Cap |           Memory-Usage | GPU-Util  Compute M. |
|                                         |                        |               MIG M. |
|=========================================+========================+======================|
|   0  NVIDIA RTX 4000 SFF Ada ...    Off |   00000000:01:00.0 Off |                  Off |
| 30%   34C    P8              6W /   70W |       5MiB /  20475MiB |      0%      Default |
|                                         |                        |                  N/A |
+-----------------------------------------+------------------------+----------------------+

+-----------------------------------------------------------------------------------------+
| Processes:                                                                              |
|  GPU   GI   CI        PID   Type   Process name                              GPU Memory |
|        ID   ID                                                               Usage      |
|=========================================================================================|
|  No running processes found                                                             |
+-----------------------------------------------------------------------------------------+
```

same is required from a docker container...
`kubectl run nvidia-smi --restart=Never --rm -i --tty --image nvidia/cuda:12.6.0-base-ubuntu22.04 -- nvidia-smi`

in order to get there, we need this patched version of `kind` https://github.com/klueska/nvkind.git
to build in on the machine, go-lang 1.23 is required, it is not packaged for such distro.
Therefore `wget https://go.dev/dl/go1.23.0.linux-amd64.tar.gz` and followed by `make` command.

To validate, run:

```json
# nvkind cluster print-gpus
[
    {
        "node": "nvkind-fst2w-control-plane",
        "gpus": [
            {
                "Index": "0",
                "Name": "NVIDIA RTX 4000 SFF Ada Generation",
                "UUID": "GPU-1f2094ab-42fe-96ba-9242-ec2bcc33a633"
            }
        ]
    }
]

```

and continue the installation as described for the single node on linux.

In order to test the App creation, once in Octostar UI, proceed to create a streamlit App,
but mod the `manifest.yaml` referencing the `image: octostar/streamlit-apps-gpu:latest`
and deploy it. A quick code would be:

```python
from torch import cuda

assert cuda.is_available()
assert cuda.device_count() > 0

print(cuda.get_device_name(cuda.current_device()))

#st.header("This is a streamlit app")
#st.subheader("Connected to the Octostar")
st.header("This is a GPU powered instance")
st.subheader(cuda.get_device_name(cuda.current_device()))
```

starting right after the imports of the sample App.
