# Single-Node Demo & Development Environment

This repository provides scripts to set up either:
- A single-node demo environment for evaluating our platform
- A local development environment for contributors

Both setups use Kind (Kubernetes in Docker) to create a lightweight, fully-functional Kubernetes cluster on your machine.

## Prerequisites

- For macOS: Docker Desktop
- For Linux: Docker Engine
- For Windows: Docker Desktop + WSL2 with Debian-based distribution
- Git

## Quick Start for Demo Setup

1. Clone this repository:
```bash
git clone <repository-url>
cd <repository-directory>
```

2. Run the installation script:
```bash
./bin/install.sh
```

The script automatically handles everything you need:
- Installing required tools
- Creating a local Kubernetes cluster
- Setting up certificates and DNS
- Deploying all necessary services

Once installation completes, you'll have a fully functional demo environment ready to use.

## Platform Support

Works on:
- macOS (Both Apple Silicon M1/M2 and Intel Macs)
- Linux (64-bit x86 and ARM)
- Windows via WSL2 (Windows Subsystem for Linux)
  - Requires a Debian-based distribution (Ubuntu recommended)
  - After WSL2 setup, follow the Linux instructions inside your WSL2 terminal

## Installation Options

The install script supports these optional flags:

```bash
# Clean reinstall of the environment
./bin/install.sh --reinstall

# Enable NVIDIA GPU support (Linux/WSL2 only)
./bin/install.sh --nvidia
```

## Common Operations

Update your environment:
```bash
./bin/update-existing.sh
```

Remove the environment:
```bash
./bin/destroy.sh
```

## Troubleshooting

Common issues and solutions:

1. **Docker Issues**
   - Ensure Docker is running
   - Check Docker has at least 20GB memory allocated (Docker Desktop Settings)
   - Verify you have the latest Docker version
   - For WSL2: Ensure Docker Desktop's "Use WSL2 based engine" is enabled

2. **Permission Issues**
   - The script may need sudo access to modify /etc/hosts
   - Ensure your user has permission to run Docker commands
   - For WSL2: Run `sudo usermod -aG docker $USER` if needed

3. **Resource Issues**
   - Close resource-intensive applications
   - Ensure your system has at least 16GB RAM recommended
   - For WSL2: Check .wslconfig file for memory limits

4. **WSL2 Specific Issues**
   - Ensure you're using a Debian-based distribution
   - Run `wsl --status` to verify you're using WSL2 (not WSL1)
   - Check Docker Desktop's WSL Integration is enabled for your distribution

For additional support:
- Check the console output for detailed error messages
- Contact our support team at <support-email>
- File an issue in this repository

## For Developers

If you're a developer looking to contribute:
- Check our [Contributing Guidelines](CONTRIBUTING.md)
- See the [Developer Documentation](docs/development.md) for detailed setup
- Join our developer community on [Slack/Discord]

## License

Octostar Limited - 2024
All rights reserved.