brew install helm helmfile kubernetes-cli dnsmasq
helmfile init --force

mkdir -p "$(brew --prefix)/etc/dnsmasq.d/"
echo "address=/test/127.0.0.1" > "$(brew --prefix)/etc/dnsmasq.d/test.conf"
sudo mkdir -p "$(brew --prefix)/var/run/dnsmasq"
sudo brew services start dnsmasq