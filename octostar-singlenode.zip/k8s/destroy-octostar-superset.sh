#!/bin/bash

current_context=$(kubectl config current-context)

# echo "???? ${BASH_SOURCE[1]}"
# exit 1 <- the above gets populated only if we "source" this file
if [[ -z "${BASH_SOURCE[1]}" ]]; then
  echo "current kubectl context is '${current_context}'"
  # this in case it is not a single node chained installation on a `kind` cluster
  if [[ ! "$current_context" =~ ^kind-.* ]]; then
      echo "Current kubectl context is '$current_context', not 'kind-*'. Exiting..."
      exit 1
  fi

  read -p "You are about to destroy octostar-superset in the '$current_context' context. Type 'yes' to proceed: " confirmation_octostar

  if [ "$confirmation_octostar" != "yes" ]; then
      echo "Exiting..."
      exit 1
  fi
fi

if [ -f /tmp/rootCA.pem ]; then
  rm /tmp/rootCA.pem
fi

kubectl delete jobs.batch -n octostar-main --all
helmfile -f "./k8s/helmfile-octostar.yaml" destroy
