#!/bin/bash

current_context=$(kubectl config current-context)
echo "current kubectl context is '${current_context}'"

if [[ ! "$current_context" =~ ^kind-.* ]]; then
    echo "Current kubectl context is '$current_context', not 'kind-*'. Exiting..."
    exit 1
fi

read -p "You are about to destroy octostar-singlenode in the '$current_context' context. Type 'yes' to proceed: " confirmation

if [ "$confirmation" != "yes" ]; then
    echo "Exiting..."
    exit 1
fi

source "./k8s/destroy-octostar-superset.sh"

helmfile -f "./k8s/helmfile-data.yaml" destroy
helmfile -f "./k8s/helmfile.yaml" destroy

kubectl delete -f https://github.com/cert-manager/cert-manager/releases/download/v1.13.2/cert-manager.crds.yaml
kubectl delete -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/kind/deploy.yaml

# FIXME / TODO: DNS rewriting within k8s
kubectl apply -f k8s/coredns/coredns.cm.orig

kubectl -n octostar-main delete pvc --all

kubectl delete -f https://raw.githubusercontent.com/Altinity/clickhouse-operator/release-0.23.6/deploy/helm/clickhouse-operator/crds/CustomResourceDefinition-clickhouseinstallations.clickhouse.altinity.com.yaml
kubectl delete -f https://raw.githubusercontent.com/Altinity/clickhouse-operator/release-0.23.6/deploy/helm/clickhouse-operator/crds/CustomResourceDefinition-clickhousekeeperinstallations.clickhouse-keeper.altinity.com.yaml
kubectl delete -f https://raw.githubusercontent.com/Altinity/clickhouse-operator/release-0.23.6/deploy/helm/clickhouse-operator/crds/CustomResourceDefinition-clickhouseinstallationtemplates.clickhouse.altinity.com.yaml
kubectl delete -f https://raw.githubusercontent.com/Altinity/clickhouse-operator/release-0.23.6/deploy/helm/clickhouse-operator/crds/CustomResourceDefinition-clickhouseoperatorconfigurations.clickhouse.altinity.com.yaml
kubectl get crd | grep 'traefik' | awk '{ print $1 }' | xargs kubectl delete crd

kubectl delete namespace/octostar-main
kubectl delete namespace/cert-manager
kubectl delete namespace/otlp
kubectl delete namespace/traefik-v2
