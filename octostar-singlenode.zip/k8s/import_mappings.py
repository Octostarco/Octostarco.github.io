# EXPORT ONTOLOGY MAPPINGS in sql lab
# export result as CSV
# Use this shitty python program to filter the local and unused
# Paste everything in SQL LAB again
import csv
import re

replace_pattern = re.compile("vdemo3|vdemo4|idtest")
replacement_db = "default"

csv_file_path = './exported_mappings_1709233014266.csv'

with open(csv_file_path, newline='', encoding='utf-8') as csvfile:
    csv_reader = csv.reader(csvfile)

    # Skip the header row if there is one
    next(csv_reader, None)

    for row in csv_reader:
        text = row[0]
        if "FROM `default`.`os_ontology_v1_os_local_" not in text and "docpoc" not in text and "nyc_" in text:
            transformed = re.sub(pattern=replace_pattern, repl=replacement_db, string=text)
            print("\n\n\n" + transformed)