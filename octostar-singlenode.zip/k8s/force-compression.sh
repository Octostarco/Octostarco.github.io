#!/bin/bash
kubectl patch cm -n ingress-nginx ingress-nginx-controller -p \
'{"data":{"use-gzip":"true","gzip-types":"*"}}'
# we need a force restart!!! -> it won't pickup the change otherwise
kubectl delete pod -n ingress-nginx --all
