#!/bin/bash
helmfile -f "./k8s/helmfile.yaml" sync
helmfile -f "./k8s/helmfile-octostar.yaml" sync
