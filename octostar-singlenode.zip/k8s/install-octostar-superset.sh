#!/bin/bash
current_context=$(kubectl config current-context)
OCTOSTAR_NAMESPACE=octostar-main

if [[ "$current_context" != "docker-desktop" && "$string" =~ ^kind- ]]; then
   echo "Current context is '$current_context', not 'docker-desktop' or 'kind-*'. Exiting..."
   exit 1
fi

# echo "???? ${BASH_SOURCE[1]}"
# exit 1 <- the above gets populated only if we "source" this file
if [[ -z "${BASH_SOURCE[1]}" ]]; then
  # this in case it is not a single node chained installation on a `kind` cluster
  read -p "Do you want to install octostar-singlenode in the '$current_context' context? Type 'yes' to proceed: " confirmation_octostar

  if [ "$confirmation_octostar" != "yes" ]; then
      echo "Exiting..."
      exit 1
  fi
fi

# Generate a complete root certification authorities bundle
# that includes both system and custom root certificates in a distribution-agnostic way.

OUTPUT_CA_BUNDLE="/tmp/rootCA.pem"
CUSTOM_ROOT_CA="k8s/rootCA.pem"

if command -v openssl &> /dev/null; then
  # Use OpenSSL's cert directory if available
  SYSTEM_CERT_DIR=$(openssl version -d | awk -F'"' '{print $2}')/certs
  cat "$SYSTEM_CERT_DIR"/*.pem "$CUSTOM_ROOT_CA" > "$OUTPUT_CA_BUNDLE"
elif [[ "$OSTYPE" == "darwin"* ]]; then
  # On macOS, use the security tool to extract system certificates
  security find-certificate -a -p /System/Library/Keychains/SystemRootCertificates.keychain > "$OUTPUT_CA_BUNDLE"
  cat "$CUSTOM_ROOT_CA" >> "$OUTPUT_CA_BUNDLE"
else
  # For other systems, default to custom root CA only
  cp "$CUSTOM_ROOT_CA" "$OUTPUT_CA_BUNDLE"
fi

# Final output status
if [ -f "$OUTPUT_CA_BUNDLE" ]; then
  echo "Root CA bundle generated at $OUTPUT_CA_BUNDLE"
else
  echo "Failed to create Root CA bundle" >&2
  exit 1
fi

kubectl create configmap root-ca -n $OCTOSTAR_NAMESPACE --from-file=/tmp/rootCA.pem -o yaml --dry-run=client | kubectl apply -f -

echo "Installing octostar-superset..."
helmfile -f "./k8s/helmfile-octostar.yaml" sync

echo "Waiting for octostar-frontend deployment to be ready..."
until kubectl -n $OCTOSTAR_NAMESPACE wait --for=condition=available --timeout=600s deployment/octostar-frontend; do
  echo "Waiting for octostar-frontend to become ready..."
  sleep 5
done

# https://app.clickup.com/t/24535548/DEV-2223
RANDOM_PASSWORD=$(cat /dev/urandom | tr -dc '[:alnum:]' | head -c 20)
kubectl exec -n $OCTOSTAR_NAMESPACE svc/octostar-frontend -- superset fab create-admin --username admin --firstname WPS --lastname Admin --email admin@fab.org --password $RANDOM_PASSWORD
kubectl exec -n $OCTOSTAR_NAMESPACE svc/octostar-frontend -- superset db upgrade
kubectl exec -n $OCTOSTAR_NAMESPACE svc/octostar-frontend -- superset init

echo "octostar-frontend is ready."
echo "octostar-superset installed!"
