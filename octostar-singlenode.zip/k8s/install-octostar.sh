#!/bin/bash
current_context=$(kubectl config current-context)

# NOTE: the checks below could be put in a helmfile prepare hook, however
# the logs won't be displayed when running from a script.
OCTOSTAR_NAMESPACE=octostar-main

if [[ "$current_context" != "docker-desktop" && "$string" =~ ^kind- ]]; then
    echo "Current context is '$current_context', not 'docker-desktop' or 'kind-kind'. Exiting..."
    exit 1
fi

read -p "You are about to install octostar-singlenode in the '$current_context' context. Type 'yes' to proceed: " confirmation

if [ "$confirmation" != "yes" ]; then
    echo "Exiting..."
    exit 1
fi

kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.13.2/cert-manager.crds.yaml || true
kubectl apply -f https://raw.githubusercontent.com/Altinity/clickhouse-operator/release-0.23.6/deploy/helm/clickhouse-operator/crds/CustomResourceDefinition-clickhouseinstallations.clickhouse.altinity.com.yaml || true
kubectl apply -f https://raw.githubusercontent.com/Altinity/clickhouse-operator/release-0.23.6/deploy/helm/clickhouse-operator/crds/CustomResourceDefinition-clickhousekeeperinstallations.clickhouse-keeper.altinity.com.yaml || true
kubectl apply -f https://raw.githubusercontent.com/Altinity/clickhouse-operator/release-0.23.6/deploy/helm/clickhouse-operator/crds/CustomResourceDefinition-clickhouseinstallationtemplates.clickhouse.altinity.com.yaml || true
kubectl apply -f https://raw.githubusercontent.com/Altinity/clickhouse-operator/release-0.23.6/deploy/helm/clickhouse-operator/crds/CustomResourceDefinition-clickhouseoperatorconfigurations.clickhouse.altinity.com.yaml || true

CHECK_TIMEOUT=120
DATA_TIMEOUT=600
INGRESS_NAMESPACE=ingress-nginx
INGRESS_SERVICE=ingress-nginx-controller
INGRESS_DEPLOYMENT=ingress-nginx-controller

kubectl create ns cert-manager || true
kubectl create ns octostar-main || true
kubectl create ns ingress-nginx || true

helm repo update

helmfile -f "./k8s/ingress-nginx.yaml" sync
# the above got split out to have a single helmfile.yaml for both kind and !kind scenarios
echo "Waiting for $INGRESS_DEPLOYMENT deployment to be ready..."
until kubectl -n $INGRESS_NAMESPACE wait --for=condition=available --timeout=600s deployment/$INGRESS_DEPLOYMENT; do
  echo "Waiting for $INGRESS_DEPLOYMENT to become ready..."
  sleep 5
done
echo "$INGRESS_DEPLOYMENT is ready."

helmfile -f "./k8s/helmfile.yaml" sync

echo "Waiting for timbr-frontend deployment to be ready..."
until kubectl -n $OCTOSTAR_NAMESPACE wait --for=condition=available --timeout=600s deployment/timbr-frontend; do
  echo "Waiting for timbr-frontend to become ready..."
  sleep 5
done
echo "timbr-frontend is ready."

echo "Waiting for timbr-server deployment to be ready..."
until kubectl -n $OCTOSTAR_NAMESPACE wait --for=condition=available --timeout=600s deployment/timbr-server; do
  echo "Waiting for timbr-server to become ready..."
  sleep 5
done
echo "timbr-server is ready."

# FIXME / TODO: DNS rewriting within k8s
kubectl apply -f k8s/coredns.cm.yaml

# WARNING: we need superset to initialize the databases.
# therefore... this will install superset...
source  "./k8s/install-octostar-superset.sh"
# and we will remove it right after the DB has been initialized.

source ./k8s/force-compression.sh # https://app.clickup.com/t/24535548/DEV-2166

echo "Initializing the local datasource, this will take some time..."
helmfile -f "./k8s/helmfile-data.yaml" sync
echo "Local datasource initialized correctly!"

# not everyone wants superset locally, so... you'll have to reinstall it (quick hack without "yq")
grep ^workflow: k8s/local-env.yaml |grep -v demo && helmfile -f "./k8s/helmfile-octostar.yaml" destroy

echo "local-env installed!"
