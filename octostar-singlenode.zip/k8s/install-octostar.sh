#!/bin/bash

# Check if nvkind command exists
if command -v nvkind &> /dev/null
then
    echo "nvkind command found! Checking if there is a cluster..."
    output=$(nvkind cluster list)

    if [[ -z "$output" ]]; then
        nvkind create cluster --config-template=k8s/kind/privilege-ports.nvkind.yaml
    else
        echo "nvkind cluster(s) found!"
    fi
# Check if kind command exists
elif command -v kind &> /dev/null
then
    echo "kind command found! Checking if there is a cluster..."
    output=$(kind get clusters)

    if [[ -z "$output" ]]; then
        kind create cluster --config=k8s/kind/privilege-ports.kind.yaml
    else
        echo "kind cluster(s) found!"
    fi
# Neither command exists
else
    echo "Error: Neither nvkind nor kind command is available. Please install before continuing."
    exit 1
fi

current_context=$(kubectl config current-context)
echo "current kubectl context is '${current_context}'"

# NOTE: the checks below could be put in a helmfile prepare hook, however
# the logs won't be displayed when running from a script.
OCTOSTAR_NAMESPACE=octostar-main

if [[ ! "$current_context" =~ ^kind-.* ]]; then
   echo "Current kubectl context is '$current_context', not 'kind-*'. Exiting..."
   exit 1
fi

read -p "You are about to install octostar-singlenode in the '$current_context' context. Type 'yes' to proceed: " confirmation

if [ "$confirmation" != "yes" ]; then
    echo "Exiting..."
    exit 1
fi

kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.13.2/cert-manager.crds.yaml || true
kubectl apply -f https://raw.githubusercontent.com/Altinity/clickhouse-operator/release-0.23.6/deploy/helm/clickhouse-operator/crds/CustomResourceDefinition-clickhouseinstallations.clickhouse.altinity.com.yaml || true
kubectl apply -f https://raw.githubusercontent.com/Altinity/clickhouse-operator/release-0.23.6/deploy/helm/clickhouse-operator/crds/CustomResourceDefinition-clickhousekeeperinstallations.clickhouse-keeper.altinity.com.yaml || true
kubectl apply -f https://raw.githubusercontent.com/Altinity/clickhouse-operator/release-0.23.6/deploy/helm/clickhouse-operator/crds/CustomResourceDefinition-clickhouseinstallationtemplates.clickhouse.altinity.com.yaml || true
kubectl apply -f https://raw.githubusercontent.com/Altinity/clickhouse-operator/release-0.23.6/deploy/helm/clickhouse-operator/crds/CustomResourceDefinition-clickhouseoperatorconfigurations.clickhouse.altinity.com.yaml || true

CHECK_TIMEOUT=120
DATA_TIMEOUT=600
INGRESS_NAMESPACE=ingress-nginx
INGRESS_SERVICE=ingress-nginx-controller
INGRESS_DEPLOYMENT=ingress-nginx-controller

kubectl create ns cert-manager || true
kubectl create ns octostar-main || true

helm repo update

# Generate a complete root certification authorities bundle
# that includes both system and custom root certificates in a distribution-agnostic way.

OUTPUT_CA_BUNDLE="/tmp/rootCA.pem"
CUSTOM_ROOT_CA="k8s/rootCA.pem"

if command -v openssl &> /dev/null; then
  # Use OpenSSL's cert directory if available
  SYSTEM_CERT_DIR=$(openssl version -d | awk -F'"' '{print $2}')/certs
  cat "$SYSTEM_CERT_DIR"/*.pem "$CUSTOM_ROOT_CA" > "$OUTPUT_CA_BUNDLE"
elif [[ "$OSTYPE" == "darwin"* ]]; then
  # On macOS, use the security tool to extract system certificates
  security find-certificate -a -p /System/Library/Keychains/SystemRootCertificates.keychain > "$OUTPUT_CA_BUNDLE"
  cat "$CUSTOM_ROOT_CA" >> "$OUTPUT_CA_BUNDLE"
else
  # For other systems, default to custom root CA only
  cp "$CUSTOM_ROOT_CA" "$OUTPUT_CA_BUNDLE"
fi

# Final output status
if [ -f "$OUTPUT_CA_BUNDLE" ]; then
  echo "Root CA bundle generated at $OUTPUT_CA_BUNDLE"
else
  echo "Failed to create Root CA bundle" >&2
  exit 1
fi

kubectl create configmap root-ca -n $OCTOSTAR_NAMESPACE --from-file=/tmp/rootCA.pem -o yaml --dry-run=client | kubectl apply -f -

helmfile -f "./k8s/helmfile.yaml" sync

echo "Waiting for timbr-frontend deployment to be ready..."
until kubectl -n $OCTOSTAR_NAMESPACE wait --for=condition=available --timeout=600s deployment/timbr-frontend; do
  echo "Waiting for timbr-frontend to become ready..."
  sleep 5
done
echo "timbr-frontend is ready."

echo "Waiting for timbr-server deployment to be ready..."
until kubectl -n $OCTOSTAR_NAMESPACE wait --for=condition=available --timeout=600s deployment/timbr-server; do
  echo "Waiting for timbr-server to become ready..."
  sleep 5
done
echo "timbr-server is ready."

# FIXME / TODO: DNS rewriting within k8s
kubectl apply -f k8s/coredns/coredns.cm.yaml

# we directly install superset (if we are in a singlenode scenario)
# "source" is for the other script to be able to detect the chain of calls
source "./k8s/install-octostar-superset.sh"
# all installations happen before the "nginx" installation / webhook

# FIXME: this to avoid the webhook issue ...
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/kind/deploy.yaml
# https://app.clickup.com/t/24535548/TEAM-222

echo "Waiting for $INGRESS_DEPLOYMENT deployment to be ready..."
until kubectl -n $INGRESS_NAMESPACE wait --for=condition=available --timeout=600s deployment/$INGRESS_DEPLOYMENT; do
  echo "Waiting for $INGRESS_DEPLOYMENT to become ready..."
  sleep 5
done
echo "$INGRESS_DEPLOYMENT is ready."

# apply compression to nginx ingress controller
# https://app.clickup.com/t/24535548/DEV-2166
kubectl patch cm -n ingress-nginx ingress-nginx-controller -p \
'{"data":{"use-gzip":"true","gzip-types":"*"}}'
# we need a force restart!!! -> it won't pickup the change otherwise
kubectl delete pod -n ingress-nginx --all

echo "Initializing the local datasource, this will take some time..."
helmfile -f "./k8s/helmfile-data.yaml" sync
echo "Local datasource initialized correctly!"

# not everyone wants superset locally, so... you'll have to reinstall it (quick hack without "yq")
grep ^workflow: k8s/local-env.yaml | grep -v demo && helmfile -f "./k8s/helmfile-octostar.yaml" destroy

echo "local-env installed!"
