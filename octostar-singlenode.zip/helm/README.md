# helm

This folder contains a local Helm chart for the initialization of some secrets.